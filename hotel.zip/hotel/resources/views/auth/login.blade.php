<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hotel Login</title>
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
    body {
        height: 100vh;
        background: url('{{ asset("images/lobby.jpg") }}') no-repeat center center/cover;
        position: relative;
    }

    /* Area Konten Kanan */
    .right-content {
        position: absolute;
        right: 8%;
        top: 50%;
        transform: translateY(-50%);
        color: white;
        max-width: 350px;
        text-align: right;
    }
    .right-content h1 {
        font-size: 48px;
        color: #f0c75e;
        margin-bottom: 15px;
    }
    .right-content p {
        font-size: 18px;
        margin-bottom: 30px;
        line-height: 1.5;
    }
    .right-content button {
        background: #f0c75e;
        color: #0c1f3a;
        font-weight: bold;
        padding: 15px 40px;
        border: none;
        border-radius: 6px;
        font-size: 18px;
        cursor: pointer;
        transition: 0.3s;
    }
    .right-content button:hover {
        background: #d4a52f;
    }

    /* Popup */
    .popup {
        display: none;
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 999;
        backdrop-filter: blur(6px);
    }
    .popup-box {
        display: flex;
        background: white;
        width: 800px;
        height: 450px;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 10px 40px rgba(0,0,0,0.6);
        position: relative;
        animation: fadeIn 0.3s ease;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: scale(0.8); }
        to { opacity: 1; transform: scale(1); }
    }

    /* Tombol X di dalam box */
    .close-btn {
        position: absolute;
        top: 15px;
        right: 20px;
        font-size: 28px;
        font-weight: bold;
        color: #555;
        cursor: pointer;
        transition: 0.3s;
    }
    .close-btn:hover {
        color: #f0c75e;
    }

    /* Gambar kiri */
    .popup-image {
        flex: 1;
        background: url('{{ asset("images/center.jpg") }}') no-repeat center center/cover;
    }

    /* Form kanan */
    .popup-form {
        flex: 1;
        padding: 40px;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
    .popup-form h2 {
        margin-bottom: 20px;
        color: #0c1f3a;
    }
    .popup-form input {
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 6px;
    }
    .popup-form button {
        width: 100%;
        padding: 12px;
        background: #f0c75e;
        color: #0c1f3a;
        font-size: 16px;
        font-weight: bold;
        border: none;
        border-radius: 6px;
        cursor: pointer;
    }
    .popup-form .register-text {
        margin-top: 15px;
        font-size: 14px;
        text-align: center;
    }
    .popup-form .register-text a {
        color: #f0c75e;
        text-decoration: none;
        font-weight: bold;
        margin-left: 5px;
    }
</style>
</head>
<body>

<!-- Konten Kanan -->
<div class="right-content">
    <h1>Hotel & Resort</h1>
    <p>Nikmati pengalaman menginap mewah dan nyaman hanya untuk Anda.</p>
    <button id="loginBtn">LOGIN</button>
</div>

<!-- Popup -->
<div class="popup" id="popupLogin">
    <div class="popup-box">
        <span class="close-btn" id="closePopup">&times;</span>
        <div class="popup-image"></div>
        <div class="popup-form">
            <h2>Login</h2>
            <form action="{{ route('login.submit') }}" method="POST">
                @csrf
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">SIGN IN</button>
            </form>
            <div class="register-text">
                Belum punya akun? <a href="{{ route('register') }}">Daftar</a>
            </div>
        </div>
    </div>
</div>

<script>
    const loginBtn = document.getElementById('loginBtn');
    const popup = document.getElementById('popupLogin');
    const closePopup = document.getElementById('closePopup');

    loginBtn.addEventListener('click', () => {
        popup.style.display = 'flex';
    });

    closePopup.addEventListener('click', () => {
        popup.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === popup) {
            popup.style.display = 'none';
        }
    });
</script>

</body>
</html>
