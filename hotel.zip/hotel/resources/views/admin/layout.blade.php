<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') - Admin Panel</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { display: flex; background: #f4f6f9; min-height: 100vh; }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: #0c1f3a;
            color: #fff;
            display: flex;
            flex-direction: column;
            padding: 20px;
            position: fixed;
            height: 100%;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 40px;
            color: #f0c75e;
        }
        .sidebar a {
            text-decoration: none;
            color: #fff;
            padding: 12px;
            display: block;
            border-radius: 6px;
            margin-bottom: 10px;
            transition: 0.3s;
            font-size: 15px;
        }
        .sidebar a:hover,
        .sidebar a.active {
            background: #f0c75e;
            color: #0c1f3a;
        }

        /* Main content */
        .main {
            margin-left: 260px;
            padding: 30px;
            flex: 1;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .header h1 {
            font-size: 26px;
        }
        .logout-btn {
            background: #ef4444;
            color: #fff;
            padding: 10px 18px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }
        .logout-btn:hover {
            background: #dc2626;
        }

        /* Table */
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        th, td {
            padding: 14px 16px;
            border-bottom: 1px solid #e5e7eb;
            text-align: left;
            font-size: 14px;
        }
        th {
            background: #f3f4f6;
            text-transform: uppercase;
            font-size: 13px;
        }
        img {
            max-width: 90px;
            border-radius: 6px;
        }

        /* Buttons */
        .btn {
            padding: 8px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }
        .btn-edit {
            background: #facc15;
        }
        .btn-delete {
            background: #ef4444;
            color: white;
        }
        .btn-add {
            display: inline-block;
            margin-bottom: 20px;
            padding: 12px 20px;
            background: #4f46e5;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            transition: 0.3s;
        }
        .btn-add:hover {
            background: #4338ca;
        }

        .alert-success {
            background: #d1fae5;
            padding: 12px;
            border-radius: 6px;
            color: #065f46;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="{{ route('admin.rooms.index') }}" class="{{ request()->routeIs('rooms.*') ? 'active' : '' }}">Manajemen Kamar</a>
    <a href="{{ route('admin.reservations.index') }}" class="{{ request()->routeIs('reservations.*') ? 'active' : '' }}">Manajemen Reservasi</a>
    <form action="{{ route('logout') }}" method="POST" style="margin-top:auto;">
        @csrf
        <button class="logout-btn" style="width:100%;">Logout</button>
    </form>
</div>

<!-- Main Content -->
<div class="main">
    <div class="header">
        <h1>@yield('title')</h1>
    </div>
    @yield('content')
</div>

</body>
</html>
