<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Kamar</title>
    <style>
        body { font-family: sans-serif; padding: 40px; background: #f9fafb; }
        form { max-width: 500px; background: white; padding: 20px; border-radius: 10px; }
        input, select, textarea {
            width: 100%; padding: 10px; margin-bottom: 15px;
            border: 1px solid #ccc; border-radius: 6px;
        }
        button {
            background: #4f46e5; color: white;
            padding: 10px 20px; border: none; border-radius: 6px;
        }
        a { display: inline-block; margin-top: 20px; color: #4f46e5; }
        img { max-width: 100%; border-radius: 6px; margin-top: 10px; }
    </style>
</head>
<body>
    <h1>Edit Kamar</h1>

    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.rooms.update', $room->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <label>Nama Kamar</label>
        <input type="text" name="name" value="{{ old('name', $room->name) }}" required>

        <label>Deskripsi</label>
        <textarea name="description">{{ old('description', $room->description) }}</textarea>

        <label>Tipe Kamar</label>
        <select name="type" required>
            <option value="Standard" {{ $room->type == 'Standard' ? 'selected' : '' }}>Standard</option>
            <option value="Deluxe" {{ $room->type == 'Deluxe' ? 'selected' : '' }}>Deluxe</option>
            <option value="Suite" {{ $room->type == 'Suite' ? 'selected' : '' }}>Suite</option>
        </select>

        <label>Harga per Malam</label>
        <input type="number" name="price_per_night" value="{{ old('price_per_night', $room->price_per_night) }}" required>

        <label>Jumlah Tersedia</label>
        <input type="number" name="available_rooms" value="{{ old('available_rooms', $room->available_rooms) }}" required>

        <label>Ganti Foto</label>
        <input type="file" name="photo" accept="image/*">

        @if ($room->photo)
            <p>Foto Sekarang:</p>
            <img src="{{ asset('storage/' . $room->photo) }}" alt="Foto kamar" style="width: 150px;">
        @endif

        <button type="submit">Simpan Perubahan</button>
    </form>

    <a href="{{ route('admin.rooms.index') }}">← Kembali</a>
</body>
</html>
