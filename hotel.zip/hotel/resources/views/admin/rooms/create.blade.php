<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Kamar</title>
    <style>
        body { font-family: sans-serif; padding: 40px; background: #f9fafb; }
        form { max-width: 500px; background: white; padding: 20px; border-radius: 10px; }
        input, select, textarea {
            width: 100%; padding: 10px; margin-bottom: 15px;
            border: 1px solid #ccc; border-radius: 6px;
        }
        button {
            background: #4f46e5; color: white;
            padding: 10px 20px; border: none; border-radius: 6px;
        }
        a { display: inline-block; margin-top: 20px; color: #4f46e5; }
    </style>
</head>
<body>
    <h1>Tambah Kamar</h1>

    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.rooms.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <label>Nama Kamar</label>
        <input type="text" name="name" required>

        <label>Deskripsi</label>
        <textarea name="description"></textarea>

        <label>Tipe Kamar</label>
        <select name="type" required>
            <option value="Standard">Standard</option>
            <option value="Deluxe">Deluxe</option>
            <option value="Suite">Suite</option>
        </select>

        <label>Harga per Malam</label>
        <input type="number" name="price_per_night" required>

        <label>Jumlah Tersedia</label>
        <input type="number" name="available_rooms" required>

        <label>Foto</label>
        <input type="file" name="photo" accept="image/*">

        <button type="submit">Simpan</button>
    </form>

    <a href="{{ route('admin.rooms.index') }}">← Kembali</a>
</body>
</html>
