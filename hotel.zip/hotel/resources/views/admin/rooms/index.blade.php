@extends('admin.layout')

@section('title', 'Manajemen Kamar')

@section('content')

@if(session('success'))
    <div class="alert-success">{{ session('success') }}</div>
@endif

<a href="{{ route('admin.rooms.create') }}" class="btn-add">+ Tambah Kamar</a>


<table>
    <thead>
        <tr>
            <th>Nama</th>
            <th>Tipe</th>
            <th>Harga</th>
            <th>Tersedia</th>
            <th>Foto</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @forelse ($rooms as $room)
            <tr>
                <td>{{ $room->name }}</td>
                <td>{{ $room->type }}</td>
                <td>Rp{{ number_format($room->price_per_night, 0, ',', '.') }}</td>
                <td>{{ $room->available_rooms }}</td>
                <td>
                    @if($room->photo)
                        <img src="{{ asset('storage/' . $room->photo) }}" alt="Foto Kamar" style="width: 100px;">
                    @else
                        <span>-</span>
                    @endif
                </td>

                <td>
                    <a href="{{ route('admin.rooms.edit', $room->id) }}" class="btn btn-edit">Edit</a>
                    <form action="{{ route('admin.rooms.destroy', $room->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-delete" onclick="return confirm('Yakin ingin menghapus kamar ini?')">Hapus</button>
                    </form>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="6" style="text-align:center;">Belum ada kamar.</td>
            </tr>
        @endforelse
    </tbody>
</table>

@endsection
