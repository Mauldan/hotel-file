@extends('admin.layout')

@section('title', 'Manajemen Reservasi')

@section('content')

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nama User</th>
            <th>Kamar</th>
            <th>Tanggal</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        @forelse ($reservations as $reservation)
            <tr>
                <td>{{ $reservation->id }}</td>
                <td>{{ $reservation->user->name ?? '-' }}</td>
                <td>{{ $reservation->room->name ?? '-' }}</td>
                <td>{{ $reservation->check_in }} - {{ $reservation->check_out }}</td>
                <td>{{ ucfirst($reservation->status) }}</td>
            </tr>
        @empty
            <tr>
                <td colspan="5" style="text-align:center;">Belum ada reservasi.</td>
            </tr>
        @endforelse
    </tbody>
</table>

@endsection
