<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h1>Selamat datang, {{ auth()->user()->name }}</h1>

    <p>Anda login sebagai <strong>{{ auth()->user()->role }}</strong>.</p>

    {{-- 🔴 FORM LOGOUT DI SINI --}}
    <form method="POST" action="{{ route('logout') }}">
    @csrf
    <button type="submit">Logout</button>
</form>

</body>
</html>
