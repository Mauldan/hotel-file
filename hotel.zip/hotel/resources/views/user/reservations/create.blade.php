@extends('user.layout')

@section('content')
<div class="container">
    <h1>Reservasi Kamar: {{ $room->name }}</h1>
    <p>Tipe: {{ $room->type }}</p>
    <p>Harga per Malam: Rp{{ number_format($room->price_per_night, 0, ',', '.') }}</p>

    <form action="{{ route('user.reservations.store') }}" method="POST">
        @csrf
        <input type="hidden" name="room_id" value="{{ $room->id }}">

        <div>
            <label for="check_in">Tanggal Check-In:</label>
            <input type="date" name="check_in" required>
        </div>

        <div>
            <label for="check_out">Tanggal Check-Out:</label>
            <input type="date" name="check_out" required>
        </div>

        <button type="submit">Pesan Sekarang</button>
    </form>
</div>
@endsection
