@extends('user.layout')

@section('title', 'Detail Reservasi')

@section('content')
<div class="reservation-detail">
    <div class="detail-card">
        <h2>Detail Reservasi</h2>
        
        {{-- Informasi Kamar --}}
        <div class="info">
            <p><span>Nama Kamar</span> {{ $reservation->room->name }}</p>
            <p><span>Check-in</span> {{ $reservation->check_in }}</p>
            <p><span>Check-out</span> {{ $reservation->check_out }}</p>
            @php
                $nights = \Carbon\Carbon::parse($reservation->check_in)->diffInDays(\Carbon\Carbon::parse($reservation->check_out));
            @endphp
            <p><span>Jumlah Kamar Dipesan</span> {{ $reservation->jumlah_kamar }} Kamar</p>
            <p><span>Hari</span> {{ $nights }} Hari</p>
            <p><span>Harga per Malam</span> Rp{{ number_format($reservation->room->price_per_night, 0, ',', '.') }}</p>
            <p class="total"><span>Total Harga</span> Rp{{ number_format($reservation->total_price, 0, ',', '.') }}</p>
            <p><span>Status</span> 
                <strong class="status {{ strtolower($reservation->status) }}">
                    {{ ucfirst($reservation->status) }}
                </strong>
            </p>
        </div>

        {{-- Tombol Bayar pakai Midtrans --}}
        @if($reservation->status == 'pending')
            <div class="payment-method">
                <h3>Pembayaran</h3>
                <button id="pay-button" class="pay-btn">Bayar Sekarang</button>
            </div>
        @else  
            <p class="paid">✅ Pembayaran sudah selesai</p>
        @endif
    </div>
</div>

{{-- Script Midtrans --}}
@if($reservation->status == 'pending')
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="{{ config('midtrans.client_key') }}"></script>
<script type="text/javascript">
    document.getElementById('pay-button').onclick = function () {
        window.snap.pay('{{ $snapToken }}', {
            onSuccess: function(result){
                alert("Pembayaran berhasil!");
                window.location.reload();
            },
            onPending: function(result){
                alert("Menunggu pembayaran!");
                window.location.reload();
            },
            onError: function(result){
                alert("Pembayaran gagal!");
            },
            onClose: function(){
                alert('Kamu menutup popup tanpa menyelesaikan pembayaran');
            }
        });
    };
</script>
@endif

<style>
body {
    background: #f5f5f5;
}
.reservation-detail {
    display: flex;
    justify-content: center;
    padding: 30px;
}
.detail-card {
    background: white;
    border-radius: 14px;
    padding: 24px;
    width: 100%;
    max-width: 450px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.06);
}
.detail-card h2 {
    font-size: 20px;
    font-weight: 700;
    margin-bottom: 16px;
    color: #1f2937;
}
.info p {
    margin: 10px 0;
    font-size: 14px;
    color: #374151;
    display: flex;
    justify-content: space-between;
}
.info span {
    color: #6b7280;
}
.total {
    font-weight: 700;
    color: #2563eb;
}
.status.pending { color: #f59e0b; }
.status.confirmed { color: #10b981; }
.status.cancelled { color: #ef4444; }
.payment-method {
    margin-top: 24px;
}
.payment-method h3 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 12px;
}
.pay-btn {
    width: 100%;
    padding: 12px;
    background: #2563eb;
    color: white;
    font-size: 15px;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    margin-top: 10px;
    transition: background 0.2s ease;
}
.pay-btn:hover {
    background: #1e40af;
}
.paid {
    text-align: center;
    color: #10b981;
    font-weight: 600;
    margin-top: 20px;
}
</style>
@endsection
