@extends('user.layout')

@section('title', 'Reservasi Saya')

@section('content')
<h2 style="font-size:28px; font-weight:700; margin-bottom:20px; color:#1f2937;">Riwayat Reservasi</h2>

@if(session('success'))
    <div style="background:#d1fae5; color:#065f46; padding:12px 16px; border-radius:8px; margin-bottom:20px; animation:fadeIn 0.4s ease;">
        {{ session('success') }}
    </div>
@endif

<div class="reservation-container">
    @forelse($reservations as $res)
        <div class="reservation-card">
            <div class="reservation-header">
                <h3>{{ $res->room->name }}</h3>
                <span class="status {{ strtolower($res->status) }}">{{ ucfirst($res->status) }}</span>
            </div>

            <div class="reservation-body">
                <p><strong>Check-in:</strong> {{ $res->check_in }}</p>
                <p><strong>Check-out:</strong> {{ $res->check_out }}</p>
                <p><strong>Jumlah Kamar:</strong> {{ $res->jumlah_kamar }}</p>
                <p><strong>Harga per malam:</strong> Rp{{ number_format($res->room->price_per_night, 0, ',', '.') }}</p>
                <p><strong>Total Harga:</strong> Rp{{ number_format($res->total_price, 0, ',', '.') }}</p>
            </div>

            {{-- Tombol Action --}}
            @if($res->status == 'pending')
                <div class="reservation-actions">
                    <a href="{{ route('reservations.show', $res->id) }}" class="btn-detail">Detail</a>

                    <form action="{{ route('reservations.cancel', $res->id) }}" method="POST" onsubmit="return confirm('Batalkan reservasi ini?')">
                        @csrf
                        @method('PUT')
                        <button type="submit" class="btn-cancel">Cancel</button>
                    </form>
                </div>
            @endif
        </div>
    @empty
        <p style="text-align:center; padding:20px; color:#6b7280;">Belum ada reservasi.</p>
    @endforelse
</div>

<style>
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
}

.reservation-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 16px;
}

.reservation-card {
    background: #fff;
    border-radius: 12px;
    padding: 16px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    animation: fadeIn 0.4s ease;
}

.reservation-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
}

.reservation-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.reservation-header h3 {
    font-size: 18px;
    font-weight: 600;
    color: #111827;
}

.status {
    font-size: 12px;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 20px;
    text-transform: capitalize;
}

.status.pending { background: #fef3c7; color: #92400e; }
.status.confirmed { background: #d1fae5; color: #065f46; }
.status.cancelled { background: #fee2e2; color: #991b1b; }

.reservation-body p {
    margin: 6px 0;
    color: #374151;
    font-size: 14px;
}

.reservation-actions {
    margin-top: 12px;
    display: flex;
    gap: 10px;
}

/* Tombol Detail */
.btn-detail {
    display: inline-block;
    background: #2563eb;
    color: white;
    padding: 8px 14px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 14px;
    transition: 0.2s;
}
.btn-detail:hover {
    background: #1d4ed8;
}

/* Tombol Cancel */
.btn-cancel {
    display: inline-block;
    background: #ef4444;
    color: white;
    padding: 10px 14px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 14px;
    transition: 0.2s;
    border: none;
}
.btn-cancel:hover {
    background: #dc2626;
}
</style>
@endsection
