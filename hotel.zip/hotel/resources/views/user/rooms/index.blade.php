@extends('user.layout')

@section('title', 'Daftar Kamar')

@section('content')
<style>
    /* Grid Kartu */
    .room-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        animation: fadeIn 0.8s ease-in-out;
    }

    /* Kartu Kamar */
    .room-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        position: relative;
    }
    .room-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.15);
    }

    /* Foto */
    .room-img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        transition: transform 0.4s ease;
    }
    .room-card:hover .room-img {
        transform: scale(1.05);
    }

    /* Konten */
    .room-info {
        padding: 15px;
    }
    .room-info h3 {
        margin-bottom: 6px;
        font-size: 18px;
        font-weight: 600;
        color: #1f2937;
    }
    .room-type {
        color: #6b7280;
        font-size: 14px;
        margin-bottom: 5px;
    }
    .room-price {
        font-weight: bold;
        color: #6a0dad;
        font-size: 16px;
        margin-bottom: 10px;
    }

    /* Tombol Detail */
    .btn-detail {
        display: inline-block;
        padding: 10px 14px;
        background: linear-gradient(90deg, #6a0dad, #9b4dca);
        color: white;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 500;
        transition: background 0.3s ease, transform 0.2s ease;
    }
    .btn-detail:hover {
        background: linear-gradient(90deg, #5a0cad, #8a3cbf);
        transform: scale(1.03);
    }

    /* Animasi Fade */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<h2 style="font-size:24px; margin-bottom:15px; font-weight:600;">Daftar Kamar Tersedia</h2>

<div class="room-grid">
    @foreach ($rooms as $room)
        <div class="room-card">
            @if($room->photo && Storage::disk('public')->exists($room->photo))
                <img src="{{ asset('storage/' . $room->photo) }}" alt="Foto Kamar" width="100">
            @else
                <em>Tidak ada foto</em>
            @endif
            <div class="room-info">
                <h3>{{ $room->name }}</h3>
                <p class="room-type">Tipe: {{ $room->type }}</p>
                <p class="room-price">Rp{{ number_format($room->price_per_night, 0, ',', '.') }}/malam</p>
                <a href="{{ route('user.rooms.show', $room->id) }}" class="btn-detail">Detail</a>
            </div>
        </div>
    @endforeach
</div>
@endsection
