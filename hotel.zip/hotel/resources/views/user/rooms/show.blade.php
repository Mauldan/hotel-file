@extends('user.layout')

@section('content')
<style>
    /* Animasi & Header */
    .room-header {
        position: relative;
        height: 400px;
        background-size: cover;
        background-position: center;
        border-radius: 10px;
        overflow: hidden;
        animation: fadeIn 1s ease-in-out;
    }
    .room-header::after {
        content: "";
        position: absolute;
        inset: 0;
        background: rgba(0,0,0,0.4);
    }
    .room-title {
        position: absolute;
        bottom: 20px;
        left: 20px;
        color: white;
        font-size: 2rem;
        font-weight: bold;
        z-index: 2;
    }

    /* Konten Card */
    .room-content {
        margin-top: -30px;
        background: white;
        padding: 25px;
        border-radius: 15px;
        box-shadow: 0px 5px 15px rgba(0,0,0,0.1);
        animation: slideUp 0.7s ease-in-out;
    }

    /* Input Modern */
    .input-wrapper {
        position: relative;
    }
    .input-wrapper i {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #6a0dad;
        font-size: 1.1rem;
    }
    .input-modern {
        padding: 10px 15px 10px 38px;
        border-radius: 8px;
        border: 1px solid #ccc;
        width: 100%;
        transition: border-color 0.3s, box-shadow 0.3s;
        box-sizing: border-box; 
    }
    .input-modern:focus {
        border-color: #6a0dad;
        box-shadow: 0px 0px 8px rgba(106, 13, 173, 0.3);
        outline: none;
    }

    /* Tombol Pesan */
    .btn-book {
        background: linear-gradient(90deg, #6a0dad, #9b4dca);
        color: white;
        font-weight: 500;
        padding: 10px;
        border-radius: 8px;
        border: none;
        margin-top: 15px; /* Jarak dari input */
        transition: transform 0.2s ease-in-out, box-shadow 0.3s;
    }
    .btn-book:hover {
        transform: scale(1.03);
        box-shadow: 0px 4px 12px rgba(106, 13, 173, 0.3);
    }

    /* Animasi */
    @keyframes fadeIn {
        from { opacity: 0; transform: scale(1.05); }
        to { opacity: 1; transform: scale(1); }
    }
    @keyframes slideUp {
        from { opacity: 0; transform: translateY(50px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<div class="room-header" style="background-image: url('{{ asset('storage/' . $room->photo) }}');">
    <div class="room-title">{{ $room->name }}</div>
</div>

<div class="room-content">
    <h3>{{ $room->type }} • Rp {{ number_format($room->price_per_night, 0, ',', '.') }} / malam</h3>
    <p class="text-muted">Sisa Kamar: <strong>{{ $room->available_rooms }}</strong></p>
    <p>{{ $room->description }}</p>
    <hr>

    <form action="{{ route('user.reservations.store') }}" method="POST">
        @csrf
        <input type="hidden" name="room_id" value="{{ $room->id }}">

        <div class="row">
            <div class="col-md-6 mb-3">
                <label>Check-in</label>
                <div class="input-wrapper">
                    <i class="fa fa-calendar-alt"></i>
                    <input type="date" name="check_in" class="input-modern" required>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <label>Check-out</label>
                <div class="input-wrapper">
                    <i class="fa fa-calendar-check"></i>
                    <input type="date" name="check_out" class="input-modern" required>
                </div>
            </div>
        </div>

        <div class="mb-3">
            <label>Jumlah Kamar</label>
            <div class="input-wrapper">
                <i class="fa fa-bed"></i>
                <input type="number" name="jumlah_kamar" class="input-modern" min="1" max="{{ $room->available_rooms }}" required>
            </div>
        </div>

        <button type="submit" class="btn btn-book w-100">Pesan Sekarang</button>
    </form>
</div>
@endsection
