<!DOCTYPE html>
<html>
<head>
    <title>Pembayaran</title>
</head>
<body>
    <h2>Pembayaran Reservasi</h2>
    <p>Kamar: {{ $reservation->room->name }}</p>
    <p>Total: Rp{{ number_format($reservation->total_price, 0, ',', '.') }}</p>

    <!-- Tombol Bayar -->
    <button id="pay-button">Bayar Sekarang</button>

    <!-- Midtrans Script -->
    <script src="https://app.sandbox.midtrans.com/snap/snap.js"
        data-client-key="{{ config('midtrans.client_key') }}"></script>

    <script type="text/javascript">
      document.getElementById('pay-button').onclick = function(){
        window.snap.pay('{{ $snapToken }}', {
          onSuccess: function(result){
            alert("Pembayaran sukses!");
            console.log(result);
          },
          onPending: function(result){
            alert("Menunggu pembayaran!");
            console.log(result);
          },
          onError: function(result){
            alert("Pembayaran gagal!");
            console.log(result);
          },
          onClose: function(){
            alert('Kamu menutup popup tanpa menyelesaikan pembayaran');
          }
        });
      };
    </script>
</body>
</html>
