<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Hotel Booking')</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <!-- Swiper Slider -->
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>
    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: #f8f9fa;
        }
        header {
            background: #fff;
            padding: 15px 50px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        header .logo {
            font-size: 24px;
            font-weight: bold;
            color: #6a0dad;
            letter-spacing: 1px;
        }
        nav {
            display: flex;
            align-items: center;
        }
        nav a {
            text-decoration: none;
            color: #333;
            margin: 0 15px;
            font-weight: 500;
            transition: color 0.3s;
        }
        nav a:hover {
            color: #6a0dad;
        }
        .logout-btn {
            border: none;
            background: none;
            color: #333;
            font-weight: 500;
            margin-left: 15px;
            cursor: pointer;
            transition: color 0.3s;
        }
        .logout-btn:hover {
            color: #d9534f;
        }
        main {
            min-height: 70vh;
            padding: 20px 5%;
        }
        footer {
            background: #222;
            color: #fff;
            text-align: center;
            padding: 15px;
            margin-top: 40px;
            font-size: 14px;
        }
    </style>
    @yield('styles')
</head>
<body>
    <!-- Header -->
    <header>
        <div class="logo">Hotel</div>
        <nav>
            <a href="{{ route('user.rooms.index') }}">Kamar</a>
            <a href="{{ route('user.reservations.index') }}">Reservasi Saya</a>
            <form action="{{ route('logout') }}" method="POST" style="display:inline;">
                @csrf
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </nav>
    </header>

    <!-- Main Content -->
    <main>
        @yield('content')
    </main>

    <!-- Footer -->
    <footer>
        &copy; {{ date('Y') }} Copyright.
    </footer>

    <!-- Swiper Script -->
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    @yield('scripts')
</body>
</html>
