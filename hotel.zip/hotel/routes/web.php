<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\RoomController;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\UserRoomController;
use App\Http\Controllers\UserReservationController;
use App\Http\Controllers\PaymentController;

Route::get('/payment/{id}', [PaymentController::class, 'pay'])->name('payment');

// Halaman Awal
Route::get('/', function () {
    return redirect('/login');
});

// Login
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.submit');

// Register
Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->name('register.submit');

// Logout
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Dashboard (setelah login)
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware('auth')->name('dashboard');

// Admin Routes
Route::middleware(['auth'])->group(function () {
    Route::prefix('admin')->name('admin.')->group(function () {
        Route::resource('rooms', RoomController::class);
        Route::resource('reservations', ReservationController::class)->only(['index', 'edit', 'update', 'destroy']);
    });
});

// user routes
Route::middleware(['auth'])->group(function () {
    Route::prefix('user')->group(function () {
        Route::get('/lobby', [UserRoomController::class, 'lobby'])->name('user.lobby');
        Route::get('/rooms', [UserRoomController::class, 'index'])->name('user.rooms.index');
        Route::get('/rooms/{id}', [UserRoomController::class, 'show'])->name('user.rooms.show');
        Route::post('/reservations', [UserReservationController::class, 'store'])->name('user.reservations.store');
        Route::get('/reservations', [UserReservationController::class, 'index'])->name('user.reservations.index');
        Route::get('/reservations/create/{room_id}', [UserReservationController::class, 'create'])->name('user.reservations.create');
        Route::get('/reservations/{reservation}', [App\Http\Controllers\ReservationController::class, 'show'])->name('reservations.show');
        Route::post('/payment/{reservation}', [App\Http\Controllers\PaymentController::class, 'process'])->name('payment.process');
        Route::put('/reservations/{id}/cancel', [UserReservationController::class, 'cancel'])->name('reservations.cancel');
    
    });
});


