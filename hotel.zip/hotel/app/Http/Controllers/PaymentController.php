<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reservation;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    // USER membuka halaman bayar → generate Snap Token
    public function pay($id)
    {
        $reservation = Reservation::with('user','room')->findOrFail($id);

        // Konfigurasi Midtrans
        \Midtrans\Config::$serverKey    = config('midtrans.server_key');
        \Midtrans\Config::$isProduction = (bool) config('midtrans.is_production');
        \Midtrans\Config::$isSanitized  = true;
        \Midtrans\Config::$is3ds        = true;

        // order_id WAJIB unik & konsisten; kita pakai "RES-{reservation_id}"
        $params = [
            'transaction_details' => [
                'order_id'      => 'RES-' . $reservation->id,
                'gross_amount'  => $reservation->total_price, // angka utuh; Midtrans akan kirim balik "xxxxx.00"
            ],
            'customer_details' => [
                'first_name' => $reservation->user->name ?? 'Guest',
                'email'      => $reservation->user->email ?? 'guest@example.com',
            ],
        ];

        $snapToken = \Midtrans\Snap::getSnapToken($params);

        // kirim ke view yg menampilkan tombol "Bayar Sekarang"
        return view('user.reservation.show', compact('reservation','snapToken'));
    }

    // CALLBACK dari Midtrans → update status reservasi
    public function callback(Request $request)
    {
        Log::info('Midtrans callback: ' . json_encode($request->all()));

        $serverKey = config('midtrans.server_key');

        // HASILKAN signature sama persis format Midtrans (gross_amount JANGAN diubah)
        $myHash = hash('sha512',
            $request->order_id .
            $request->status_code .
            $request->gross_amount .
            $serverKey
        );
        Log::info("My hash: $myHash | Midtrans hash: {$request->signature_key}");

        if ($myHash !== $request->signature_key) {
            Log::warning('Invalid signature');
            return response()->json(['message' => 'Invalid signature'], 403);
        }

        // Ambil reservation_id dari order_id "RES-123"
        $parts = explode('-', (string) $request->order_id);
        $reservationId = $parts[1] ?? null;

        $reservation = Reservation::with('room')->find($reservationId);
        if (!$reservation) {
            Log::warning('Reservation not found for order_id ' . $request->order_id);
            return response()->json(['message' => 'Reservation not found'], 404);
        }

        // Mapping status Midtrans → status reservasi
        $trx = $request->transaction_status;
        $fraud = $request->fraud_status;

        if ($trx === 'settlement' || ($trx === 'capture' && $fraud === 'accept')) {
            $reservation->status = 'confirmed';

            // Kurangi stok kamar (satu kali, saat sukses)
            $room = $reservation->room;
            if ($room && $room->available_rooms >= $reservation->jumlah_kamar) {
                $room->available_rooms -= $reservation->jumlah_kamar;
                $room->save();
                Log::info("Room {$room->id} stock updated → {$room->available_rooms}");
            }
        } elseif ($trx === 'pending' || ($trx === 'capture' && $fraud === 'challenge')) {
            $reservation->status = 'pending';
        } else { // cancel, expire, deny
            $reservation->status = 'cancelled';
        }

        $reservation->save();
        Log::info("Reservation {$reservation->id} updated to {$reservation->status}");

        return response()->json(['message' => 'Callback processed']);
    }
}
