<?php

namespace App\Http\Controllers;

use App\Models\Room;
use Illuminate\Http\Request;

class UserRoomController extends Controller
{
    public function index()
    {
        $rooms = Room::all();
        return view('user.rooms.index', compact('rooms'));
    }

    public function show($id)
    {
        $room = Room::findOrFail($id);
        return view('user.rooms.show', compact('room'));
    }
}
