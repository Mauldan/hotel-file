<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    // 🖼️ Tampilkan halaman login
    public function showLoginForm()
    {
        return view('auth.login');
    }

    // 🖼️ Tampilkan halaman register
    public function showRegisterForm()
    {
        return view('auth.register');
    }

    // 📝 Proses login
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();

            $user = auth()->user();

            if ($user->role === 'admin') {
                return redirect()->route('admin.rooms.index'); // Admin ke halaman manajemen kamar
            }

            return redirect()->route('user.rooms.index'); // User ke halaman daftar kamar
        }

        return back()->withErrors([
            'username' => 'Username atau password salah.',
        ]);
    }



    // 📝 Proses registrasi user baru
    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
        ]);

        User::create([
            'name' => $request->name,
            'username' => $request->username,
            'password' => Hash::make($request->password),
        ]);

        return redirect()->route('login')->with('success', 'Akun berhasil dibuat, silakan login.');
    }

    // 🚪 Logout
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }
}
