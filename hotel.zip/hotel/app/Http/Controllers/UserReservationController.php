<?php

namespace App\Http\Controllers;

use App\Models\Reservation;
use App\Models\Room;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Midtrans\Snap;
use Midtrans\Config;

class UserReservationController extends Controller
{
    public function index()
    {
        $reservations = Reservation::where('user_id', Auth::id())->with('room')->get();
        return view('user.reservations.index', compact('reservations'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'room_id' => 'required|exists:rooms,id',
            'check_in' => 'required|date',
            'check_out' => 'required|date|after:check_in',
            'jumlah_kamar' => 'required|integer|min:1',
        ]);

        $room = Room::findOrFail($request->room_id);

        // Hitung harga total
        $days = (strtotime($request->check_out) - strtotime($request->check_in)) / 86400;
        $total_price = $days * $room->price_per_night * $request->jumlah_kamar;

        Reservation::create([
            'user_id' => Auth::id(),
            'room_id' => $room->id,
            'check_in' => $request->check_in,
            'check_out' => $request->check_out,
            'total_price' => $total_price,
            'status' => 'pending', // belum bayar
            'jumlah_kamar' => $request->jumlah_kamar,
        ]);

        return redirect()->route('user.reservations.index')->with('success', 'Reservasi berhasil dibuat. Silakan lakukan pembayaran.');
    }

    public function create($room_id)
    {
        $room = Room::findOrFail($room_id);
        return view('user.reservations.create', compact('room'));
    }

    // === Cancel reservasi ===
    public function cancel($id)
    {
        $reservation = Reservation::where('id', $id)
            ->where('user_id', Auth::id())
            ->where('status', 'pending')
            ->firstOrFail();

        $reservation->status = 'cancelled';
        $reservation->save();

        return redirect()->route('user.reservations.index')
            ->with('success', 'Reservasi berhasil dibatalkan.');
    }

    // === Detail reservasi + Midtrans ===
    public function show($id)
    {
        $reservation = Reservation::with('room', 'user')->findOrFail($id);

        // Konfigurasi Midtrans
        Config::$serverKey = config('midtrans.server_key');
        Config::$isProduction = false; // sandbox mode
        Config::$isSanitized = true;
        Config::$is3ds = true;

        $params = [
            'transaction_details' => [
                'order_id' => 'RES-' . $reservation->id,
                'gross_amount' => $reservation->total_price,
            ],
            'customer_details' => [
                'first_name' => $reservation->user->name,
                'email' => $reservation->user->email ?? 'demo@example.com',
            ],
        ];

        $snapToken = Snap::getSnapToken($params);

        return view('user.reservations.show', compact('reservation', 'snapToken'));
    }
}
