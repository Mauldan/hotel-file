<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Room;
use Illuminate\Support\Facades\Storage;

class RoomController extends Controller
{
    // ✅ Tampilkan daftar kamar (Admin)
    public function index()
    {
        $rooms = Room::all();
        return view('admin.rooms.index', compact('rooms'));
    }

    // ✅ Form tambah kamar (Admin)
    public function create()
    {
        return view('admin.rooms.create');
    }

    // ✅ Simpan kamar baru (Admin)
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'            => 'required|string|max:255',
            'description'     => 'nullable|string',
            'type'            => 'required|in:Standard,Deluxe,Suite',
            'price_per_night' => 'required|numeric|min:0',
            'available_rooms' => 'required|integer|min:0',
            'photo'           => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        // Simpan foto jika ada
        if ($request->hasFile('photo')) {
            $validated['photo'] = $request->file('photo')->store('room_photos', 'public');
        }

        Room::create($validated);

        return redirect()->route('admin.rooms.index')->with('success', 'Kamar berhasil ditambahkan.');
    }

    // ✅ Form edit kamar
    public function edit(string $id)
    {
        $room = Room::findOrFail($id);
        return view('admin.rooms.edit', compact('room'));
    }

    // ✅ Update data kamar
    public function update(Request $request, string $id)
    {
        $room = Room::findOrFail($id);

        $validated = $request->validate([
            'name'            => 'required|string|max:255',
            'description'     => 'nullable|string',
            'type'            => 'required|in:Standard,Deluxe,Suite',
            'price_per_night' => 'required|numeric|min:0',
            'available_rooms' => 'required|integer|min:0',
            'photo'           => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        // Update foto jika ada file baru
        if ($request->hasFile('photo')) {
            if ($room->photo && Storage::disk('public')->exists($room->photo)) {
                Storage::disk('public')->delete($room->photo);
            }
            $validated['photo'] = $request->file('photo')->store('room_photos', 'public');
        }

        $room->update($validated);

        return redirect()->route('admin.rooms.index')->with('success', 'Kamar berhasil diperbarui.');
    }

    // ✅ Hapus kamar
    public function destroy(string $id)
    {
        $room = Room::findOrFail($id);

        if ($room->photo && Storage::disk('public')->exists($room->photo)) {
            Storage::disk('public')->delete($room->photo);
        }

        $room->delete();

        return redirect()->route('admin.rooms.index')->with('success', 'Kamar berhasil dihapus.');
    }

    // =============================
    // 🔹 Untuk User
    // =============================

    // ✅ List kamar tersedia untuk User
    public function userRooms()
    {
        $rooms = Room::where('available_rooms', '>', 0)->get();
        return view('user.rooms.index', compact('rooms'));
    }

    // ✅ Detail kamar untuk User
    public function showRoom($id)
    {
        $room = Room::findOrFail($id);
        return view('user.rooms.show', compact('room'));
    }
}
