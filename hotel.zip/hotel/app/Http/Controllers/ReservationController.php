<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reservation;
use App\Models\Room;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Midtrans\Config as MidtransConfig;
use Midtrans\Snap;

class ReservationController extends Controller
{
    // =============================
    // 🔹 ADMIN METHODS
    // =============================

    public function index()
    {
        $reservations = Reservation::with(['user', 'room'])->get();
        return view('admin.reservations.index', compact('reservations'));
    }

    public function create()
    {
        $rooms = Room::all();
        $users = User::all();
        return view('admin.reservations.create', compact('rooms', 'users'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'user_id'   => 'required|exists:users,id',
            'room_id'   => 'required|exists:rooms,id',
            'check_in'  => 'required|date',
            'check_out' => 'required|date|after:check_in',
            'quantity'  => 'required|integer|min:1',
            'status'    => 'nullable|in:pending,confirmed,cancelled'
        ]);

        $room = Room::findOrFail($request->room_id);

        if ($request->quantity > $room->available_rooms) {
            return back()->with('error', 'Jumlah kamar melebihi stok tersedia.');
        }

        $days = (strtotime($request->check_out) - strtotime($request->check_in)) / 86400;
        $total_price = $days * $room->price_per_night * $request->quantity;

        $reservation = Reservation::create([
            'user_id'     => $request->user_id,
            'room_id'     => $request->room_id,
            'check_in'    => $request->check_in,
            'check_out'   => $request->check_out,
            'jumlah_kamar'=> $request->quantity,
            'total_price' => $total_price,
            'status'      => $request->status ?? 'pending',
        ]);

        if ($reservation->status === 'confirmed') {
            $room->available_rooms -= $request->quantity;
            $room->save();
        }

        return redirect()->route('admin.reservations.index')->with('success', 'Reservasi berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $reservation = Reservation::findOrFail($id);
        $rooms = Room::all();
        $users = User::all();
        return view('admin.reservations.edit', compact('reservation', 'rooms', 'users'));
    }

    public function update(Request $request, $id)
    {
        $reservation = Reservation::findOrFail($id);

        $request->validate([
            'user_id'   => 'required|exists:users,id',
            'room_id'   => 'required|exists:rooms,id',
            'check_in'  => 'required|date',
            'check_out' => 'required|date|after:check_in',
            'status'    => 'required|in:pending,confirmed,cancelled',
            'quantity'  => 'required|integer|min:1',
        ]);

        $room = Room::findOrFail($request->room_id);
        $days = (strtotime($request->check_out) - strtotime($request->check_in)) / 86400;
        $total_price = $days * $room->price_per_night * $request->quantity;

        $oldStatus = $reservation->status;
        $oldQuantity = $reservation->jumlah_kamar;

        $reservation->update([
            'user_id'     => $request->user_id,
            'room_id'     => $request->room_id,
            'check_in'    => $request->check_in,
            'check_out'   => $request->check_out,
            'jumlah_kamar'=> $request->quantity,
            'total_price' => $total_price,
            'status'      => $request->status,
        ]);

        // stok kamar
        if ($oldStatus !== 'confirmed' && $request->status === 'confirmed') {
            $room->available_rooms -= $request->quantity;
            $room->save();
        }

        if ($oldStatus === 'confirmed' && $request->status === 'cancelled') {
            $room->available_rooms += $oldQuantity;
            $room->save();
        }

        if ($oldStatus === 'confirmed' && $request->status === 'confirmed') {
            $selisih = $request->quantity - $oldQuantity;
            if ($selisih > 0) {
                $room->available_rooms -= $selisih;
            } elseif ($selisih < 0) {
                $room->available_rooms += abs($selisih);
            }
            $room->save();
        }

        return redirect()->route('admin.reservations.index')->with('success', 'Reservasi berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $reservation = Reservation::findOrFail($id);

        if ($reservation->status === 'confirmed') {
            $room = Room::find($reservation->room_id);
            if ($room) {
                $room->available_rooms += $reservation->jumlah_kamar;
                $room->save();
            }
        }

        $reservation->delete();
        return redirect()->route('admin.reservations.index')->with('success', 'Reservasi berhasil dihapus.');
    }

    // =============================
    // 🔹 USER METHODS
    // =============================

    public function userReservations()
    {
        $reservations = Reservation::where('user_id', Auth::id())
            ->with('room')
            ->latest()
            ->get();

        return view('user.reservations.index', compact('reservations'));
    }

    public function show($id)
    {
        $reservation = Reservation::with('room')->findOrFail($id);

        if (auth()->id() !== $reservation->user_id) {
            abort(403);
        }

        $snapToken = null;

        if ($reservation->status === 'pending') {
            MidtransConfig::$serverKey    = config('midtrans.server_key');
            MidtransConfig::$isProduction = (bool) config('midtrans.is_production', false);
            MidtransConfig::$isSanitized  = true;
            MidtransConfig::$is3ds        = true;

            $params = [
                'transaction_details' => [
                    'order_id'     => 'RES-'.$reservation->id.'-'.time(),
                    'gross_amount' => (int) $reservation->total_price,
                ],
                'customer_details' => [
                    'first_name' => auth()->user()->name ?? 'User',
                    'email'      => auth()->user()->email ?? 'user@example.com',
                ],
                'item_details' => [[
                    'id'       => (string) $reservation->room_id,
                    'price'    => (int) $reservation->total_price,
                    'quantity' => 1,
                    'name'     => 'Reservasi '.$reservation->room->name,
                ]],
            ];

            $snapToken = Snap::getSnapToken($params);
        }

        return view('user.reservations.show', compact('reservation', 'snapToken'));
    }

    public function storeUser(Request $request)
    {
        $request->validate([
            'room_id'   => 'required|exists:rooms,id',
            'check_in'  => 'required|date|after_or_equal:today',
            'check_out' => 'required|date|after:check_in',
            'quantity'  => 'required|integer|min:1',
        ]);

        $room = Room::findOrFail($request->room_id);

        $days = (new \DateTime($request->check_in))
            ->diff(new \DateTime($request->check_out))
            ->days;

        if ($days <= 0) {
            return back()->with('error', 'Tanggal check-out harus setelah check-in.');
        }

        $totalPrice = $room->price_per_night * $days * $request->quantity;

        Reservation::create([
            'user_id'     => Auth::id(),
            'room_id'     => $room->id,
            'check_in'    => $request->check_in,
            'check_out'   => $request->check_out,
            'jumlah_kamar'=> $request->quantity,
            'total_price' => $totalPrice,
            'status'      => 'pending'
        ]);

        return redirect()->route('user.reservations')->with('success', 'Reservasi berhasil dikirim!');
    }
}
